<?php

echo "<h3>Include Once.php</h3><br>";

include_once ("01 class_and_object.php"); 
include_once ("01 class_and_object.php"); 

echo "<h3>require Once.php</h3><br>";

require_once ("02 constructor.php");
require_once ("02 constructor.php");