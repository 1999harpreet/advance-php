<?php

echo "<h3>Include.php</h3><br>";

include ("01 class_and_object.php"); 

echo "<h3>require.php</h3><br>";

require ("02 constructor.php");