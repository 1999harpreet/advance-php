<?php

require_once("70 builtin_namespace.php");
$obj = new CustomDateTime\DateTime();

$obj1 = new DateTime();
print_r($obj);              // Builtin Class