<?php

require_once("62 namespace.php");

### Class & Object
$employee_1 = new Myfile\Emp_details;
$employee_1->empName('Yogesh', 'PHP');
### Construct
$apple = new Myfile\Fruit;
### Inheritance With Constructor
$skul = new Myfile\Cls("Yogesh", "Pandey");